const imageURL = 'https://res.cloudinary.com/dxfdrtxi3/image/upload/v1698850810/app_logo_zthibi.png';

module.exports =  imageURL;
